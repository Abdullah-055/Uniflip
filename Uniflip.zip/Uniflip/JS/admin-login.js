// Hardcoded admin credentials
const ADMIN_CREDENTIALS = {
  username: "Admin055",
  password: "Admin055",
};

// Form and UI Elements
const loginForm = document.getElementById("adminLoginForm");
const responseMessage = document.getElementById("responseMessage");

// Handle Admin Login
loginForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();

  if (
    username === ADMIN_CREDENTIALS.username &&
    password === ADMIN_CREDENTIALS.password
  ) {
    responseMessage.textContent = "Login successful! Redirecting...";
    responseMessage.className = "success-message";

    // Simulate a redirect to the admin portal
    setTimeout(() => {
      window.location.href = "admin-portal.html";
    }, 2000);
  } else {
    responseMessage.textContent = "Invalid username or password.";
    responseMessage.className = "error-message";
  }
});
