const API_URL = "https://678406aa8b6c7a1316f678a6.mockapi.io/products/";

const addProductBtn = document.getElementById("addProductBtn");
const productForm = document.getElementById("productForm");
const productFormElement = document.getElementById("productFormElement");
const cancelBtn = document.getElementById("cancelBtn");
const productList = document.getElementById("productList");

// Fetch and display products on page load
document.addEventListener("DOMContentLoaded", fetchProducts);

// Show the Add Product form
addProductBtn.addEventListener("click", () => {
  productForm.classList.remove("hidden");
});

// Hide the Add Product form
cancelBtn.addEventListener("click", () => {
  productFormElement.reset();
  productForm.classList.add("hidden");
});

// Handle Add Product form submission
productFormElement.addEventListener("submit", async (e) => {
  e.preventDefault();

  const newProduct = {
    name: document.getElementById("productName").value,
    price: parseFloat(document.getElementById("productPrice").value),
    description: document.getElementById("productDescription").value,
    imageUrl: document.getElementById("productImage").value,
  };

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newProduct),
    });

    if (response.ok) {
      productFormElement.reset();
      productForm.classList.add("hidden");
      fetchProducts();
    } else {
      console.error("Failed to add product:", response.statusText);
    }
  } catch (error) {
    console.error("Error adding product:", error);
  }
});

// Fetch products from the API
async function fetchProducts() {
  try {
    const response = await fetch(API_URL);
    const products = await response.json();

    productList.innerHTML = "";

    products.forEach((product) => {
      const productItem = document.createElement("div");
      productItem.className = "product-item";

      productItem.innerHTML = `
        <div class="product-details">
          <h3>${product.name}</h3>
          <p>Price: $${product.price}</p>
          <p>${product.description}</p>
          <img src="${product.imageUrl}" alt="${product.name}" style="max-width: 100px;">
        </div>
        <div class="product-actions">
          <button class="btn edit-btn" onclick="editProduct('${product.id}')">Edit</button>
          <button class="btn delete-btn" onclick="deleteProduct('${product.id}')">Delete</button>
        </div>
      `;

      productList.appendChild(productItem);
    });
  } catch (error) {
    console.error("Error fetching products:", error);
  }
}

// Edit a product
function editProduct(productId) {
  // Fetch the product details from the API
  fetch(`${API_URL}/${productId}`)
    .then((response) => response.json())
    .then((product) => {
      // Populate the form with the existing product data
      document.getElementById("productName").value = product.name;
      document.getElementById("productPrice").value = product.price;
      document.getElementById("productDescription").value = product.description;
      document.getElementById("productImage").value = product.imageUrl;

      // Show the form
      productForm.classList.remove("hidden");

      // Change the form submission to update the product
      productFormElement.onsubmit = async (e) => {
        e.preventDefault();

        const updatedProduct = {
          name: document.getElementById("productName").value,
          price: parseFloat(document.getElementById("productPrice").value),
          description: document.getElementById("productDescription").value,
          imageUrl: document.getElementById("productImage").value,
        };

        try {
          const response = await fetch(`${API_URL}/${productId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updatedProduct),
          });

          if (response.ok) {
            productFormElement.reset();
            productForm.classList.add("hidden");
            fetchProducts(); // Refresh the product list
          } else {
            console.error("Failed to update product:", response.statusText);
          }
        } catch (error) {
          console.error("Error updating product:", error);
        }
      };
    })
    .catch((error) => console.error("Error fetching product details:", error));
}

// Delete a product
async function deleteProduct(productId) {
  try {
    const response = await fetch(`${API_URL}/${productId}`, {
      method: "DELETE",
    });

    if (response.ok) {
      fetchProducts();
    } else {
      console.error("Failed to delete product:", response.statusText);
    }
  } catch (error) {
    console.error("Error deleting product:", error);
  }
}
